-- To test: compile the entity, behavioral architecture, and this file as VHDL-2008.
-- Select tb_ann_layer_behavioral as the simulation top level, then Run All.
-- DIR contains weights.txt, inputs.txt, and targets.txt. N_IMG is the image count.
-- The testbench reads files, drives the layer, checks answers, and writes results.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.textio.all;
use std.env.all;

entity tb_ann_layer_behavioral is
  generic (
    DIR : string := "C:/My_Designs/ANN16by16/data/set4_16x16_10neurons/";
    N_IMG : positive := 19
  );
end entity;

architecture test of tb_ann_layer_behavioral is
  constant N_IN : positive := 256; -- One 16 by 16 image.
  constant N_OUT : positive := 10;
  signal clk : std_logic := '0';
  signal rst, start, mode, in_valid : std_logic := '0';
  signal din : std_logic_vector(15 downto 0) := (others => '0');
  signal dout : std_logic_vector(15 downto 0);
  signal out_valid, done : std_logic;
  signal out_idx : std_logic_vector(3 downto 0);
  type pixel_vector is array (0 to N_IN-1) of unsigned(7 downto 0);
  type output_vector is array (0 to N_OUT-1) of integer;

  -- Some supplied files have extra blank lines. Treat these like whitespace.
  function blank(row : string) return boolean is
  begin
    for i in row'range loop
      if row(i) /= ' ' and row(i) /= character'val(9)
        and row(i) /= character'val(13) then
        return false;
      end if;
    end loop;
    return true;
  end function;

  -- Read one record, skipping the blank lines in the supplied files.
  procedure read_data_line(file f : text; variable row : inout line) is
  begin
    loop
      assert not endfile(f) report "The data file ended too soon" severity failure;
      readline(f, row);
      exit when not blank(row.all);
    end loop;
  end procedure;

begin
  clk <= not clk after 5 ns;
  dut : entity work.ann_layer(behavioral)
    generic map (N_IN => N_IN, N_OUT => N_OUT)
    port map (
      clk => clk, rst => rst, start => start, mode => mode,
      in_valid => in_valid, din => din,
      out_valid => out_valid, out_idx => out_idx, dout => dout, done => done
    );

  process
    file f_w, f_in, f_tgt, f_out : text;
    variable l_w, l_in, l_tgt, l_out : line;
    variable value : integer;
    variable pixels : pixel_vector;
    variable target : output_vector;
    variable received, cycles : natural := 0;

    procedure tick is
    begin
      wait until rising_edge(clk);
      wait for 1 ns; -- Let the layer's clocked outputs settle before reading them.
    end procedure;

    procedure begin_job(job : std_logic) is
    begin
      mode <= job;
      start <= '1';
      tick;
      start <= '0';
      assert done = '0' and out_valid = '0'
        report "Start did not clear the previous job" severity failure;
    end procedure;
  begin
    rst <= '1';
    tick;
    rst <= '0';

    -- 1. Read each neuron's weights followed by its bias, just like the example.
    file_open(f_w, DIR & "weights.txt", read_mode);
    begin_job('0');
    for j in 0 to N_OUT-1 loop
      read_data_line(f_w, l_w);
      for i in 0 to N_IN loop
        read(l_w, value);
        assert value >= -32768 and value <= 32767
          report "Weight or bias is outside signed 16-bit range" severity failure;
        din <= std_logic_vector(to_signed(value, 16));
        in_valid <= '1';
        tick;
        assert out_valid = '0' report "Output appeared during loading" severity failure;
        if j = N_OUT-1 and i = N_IN then
          assert done = '1' report "Weight loading did not finish" severity failure;
        else
          assert done = '0' report "Weight loading finished too early" severity failure;
        end if;
      end loop;
    end loop;
    in_valid <= '0';
    file_close(f_w);

    -- 2. Read one image and its expected outputs, then run the real layer.
    file_open(f_in, DIR & "inputs.txt", read_mode);
    file_open(f_tgt, DIR & "targets.txt", read_mode);
    file_open(f_out, DIR & "behavioral_outputs.txt", write_mode);
    for k in 0 to N_IMG-1 loop
      -- Read one image: 256 integer pixels on one line.
      read_data_line(f_in, l_in);
      for i in 0 to N_IN-1 loop
        read(l_in, value);
        assert value >= 0 and value <= 255
          report "A pixel must be between 0 and 255" severity failure;
        pixels(i) := to_unsigned(value, 8);
      end loop;

      -- The matching target line has one expected result per neuron.
      read_data_line(f_tgt, l_tgt);
      for j in 0 to N_OUT-1 loop
        read(l_tgt, target(j));
        assert target(j) >= 0 and target(j) <= 32767
          report "Target is outside the ReLU output range" severity failure;
      end loop;

      begin_job('1');
      for i in 0 to N_IN-1 loop
        din <= x"00" & std_logic_vector(pixels(i));
        in_valid <= '1';
        tick;
        assert out_valid = '0' and done = '0'
          report "Layer finished before receiving the whole image" severity failure;
      end loop;
      in_valid <= '0';
      -- Begin the result line with the image number.
      write(l_out, k);
      received := 0;
      cycles := 0;
      while received < N_OUT loop
        tick;
        cycles := cycles + 1;
        assert cycles <= 10000 report "Timed out waiting for outputs" severity failure;
        if out_valid = '1' then
          assert to_integer(unsigned(out_idx)) = received
            report "Outputs arrived in the wrong neuron order" severity failure;
          value := to_integer(signed(dout));
          assert value = target(received)
            report "Wrong result: image " & integer'image(k) &
              ", neuron " & integer'image(received) &
              ", expected " & integer'image(target(received)) &
              ", got " & integer'image(value) severity failure;
          write(l_out, string'(" "));
          write(l_out, value);
          received := received + 1;
        end if;
        if received = N_OUT then
          assert done = '1' report "Final output did not set done" severity failure;
        else
          assert done = '0' report "Done arrived before all outputs" severity failure;
        end if;
      end loop;

      -- 3. Save this image's actual output values.
      writeline(f_out, l_out);
      tick;
      assert out_valid = '0' and done = '1'
        report "Done must stay high after the last output" severity failure;
    end loop;
    file_close(f_in);
    file_close(f_tgt);
    file_close(f_out);
    report "PASS: " & integer'image(N_IMG) & " images checked; see " &
      DIR & "behavioral_outputs.txt" severity note;
    stop;
    wait;
  end process;
end architecture;
