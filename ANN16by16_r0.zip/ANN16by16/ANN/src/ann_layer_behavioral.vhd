library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

architecture behavioral of ann_layer is
  -- The last column holds each neuron's bias. The other columns hold weights.
  type weight_array is array (0 to N_OUT-1, 0 to N_IN) of integer;
  type pixel_array is array (0 to N_IN-1) of integer;
  type output_array is array (0 to N_OUT-1) of integer;
  -- Keep the sum wide so large positive and negative terms do not overflow.
  type sum_array is array (0 to N_OUT-1) of signed(63 downto 0);
  type phase_type is (IDLE, LOAD_W, READ_IMG, COMPUTE, ACTIVATE, SEND_OUT);

begin
  process(clk)
    variable weights : weight_array;
    variable pixels : pixel_array;
    variable outputs : output_array;
    variable sums : sum_array;
    variable phase : phase_type := IDLE;
    variable neuron : integer range 0 to N_OUT-1 := 0;
    variable input_index : integer range 0 to N_IN := 0;
    variable scaled : signed(63 downto 0);
    variable weights_ready : boolean := false;

  begin 
    if rising_edge(clk) then
      if rst = '1' then
        phase := IDLE;
        neuron := 0;
        input_index := 0;
        weights_ready := false;
        out_valid <= '0';
        out_idx <= (others => '0');
        dout <= (others => '0');
        done <= '0';
      else
        -- Valid is high only on clocks that deliver an output.
        out_valid <= '0';
        case phase is 
          when IDLE =>
            -- The start clock selects the job. Data begins on a later clock.
            if start = '1' then
              done <= '0';
              neuron := 0;
              input_index := 0;
              if mode = '0' then
                weights_ready := false;
                phase := LOAD_W;
              elsif mode = '1' then
                assert weights_ready
                  report "Load all weights and biases before starting inference"
                  severity failure;
                if weights_ready then
                  phase := READ_IMG;
                end if;
              end if;
            end if;

          when LOAD_W =>
            -- Each neuron gets N_IN weights followed by its bias.
            -- A gap in in_valid leaves the counters where they are.
            if in_valid = '1' then
              weights(neuron, input_index) := to_integer(signed(din));
              if input_index = N_IN then
                input_index := 0;
                if neuron = N_OUT-1 then
                  weights_ready := true;
                  done <= '1';
                  phase := IDLE;
                else
                  neuron := neuron + 1;
                end if;
              else
                input_index := input_index + 1;
              end if;
            end if;

          when READ_IMG =>
            -- Only the low byte holds the unsigned pixel value.
            if in_valid = '1' then
              pixels(input_index) := to_integer(unsigned(din(7 downto 0)));
              if input_index = N_IN-1 then
                phase := COMPUTE;
              else
                input_index := input_index + 1;
              end if;
            end if;

          when COMPUTE =>
            -- Pixels have 8 fractional bits and weights have 12.
            -- Multiply the bias by 256 so every term has the same scale.
            -- These loops describe the answer, not a resource-limited circuit.
            for j in 0 to N_OUT-1 loop
              sums(j) := to_signed(weights(j, N_IN) * 256, 64);
              for i in 0 to N_IN-1 loop
                sums(j) := sums(j) + to_signed(weights(j, i) * pixels(i), 64);
              end loop;
            end loop;
            phase := ACTIVATE;

          when ACTIVATE =>
            -- ReLU turns negative sums into zero. Drop 5 fractional bits
            -- to get Q1.15, then limit the result to the largest output.
            for j in 0 to N_OUT-1 loop
              scaled := shift_right(sums(j), 5); -- Divide the raw sum by 32.
              if scaled <= 0 then
                outputs(j) := 0;
              elsif scaled > 32767 then
                outputs(j) := 32767;
              else
                outputs(j) := to_integer(scaled);
              end if;
            end loop;
            neuron := 0;
            phase := SEND_OUT;

          when SEND_OUT =>
            -- Send one neuron per clock, starting with neuron zero.
            out_valid <= '1';
            out_idx <= std_logic_vector(to_unsigned(neuron, 4));
            dout <= std_logic_vector(to_signed(outputs(neuron), 16));
            if neuron = N_OUT-1 then
              done <= '1';
              phase := IDLE;
            else
              neuron := neuron + 1;
            end if;
        end case;
      end if;
    end if;
  end process;
end architecture behavioral;
